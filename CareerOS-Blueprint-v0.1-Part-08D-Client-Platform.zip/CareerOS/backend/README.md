# Backend

Document ID: DOC-020  
Version: 0.1.0  
Status: Draft

## Purpose

The backend provides the shared service layer for CareerOS across desktop, mobile, web, browser extension, and automation clients.

## Responsibilities

- User profile service
- Resume intelligence service
- Job and application tracking service
- AI provider abstraction
- Plugin runtime coordination
- Local database access
- API gateway for clients

## Initial Technology

- Python
- FastAPI
- SQLite
- SQLAlchemy or SQLModel
- Pydantic
- Local filesystem storage
- Optional PostgreSQL migration path

## Local Path

`C:\Users\Raj\Projects\CareerOS\backend\README.md`
